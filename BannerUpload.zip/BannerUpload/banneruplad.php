<?php
/*
   Plugin Name: Banner Upload
   Plugin URI: http://www.tx-contractor.com 
   Description: Banner Upload.
   Version: 2.0 
   Author: php
   Author URI: http://www.tx-contractor.com/ 
*/
register_activation_hook(__FILE__,'create_banner_table');
register_deactivation_hook(__FILE__,'delete_banner_table');
add_action('admin_menu', 'add_banner_menu');
function create_banner_table()// Create table banner_upload For adding banner Details
{
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
global $wpdb;
global $jal_db_version;
$table_name = $wpdb->prefix . "banner_upload";
if($wpdb->get_var("show tables like '$table_name'") != $table_name) 
{
$sql = "CREATE TABLE " . $table_name . " (
id mediumint(9) NOT NULL AUTO_INCREMENT,orderno text NOT NULL,caption text NOT NULL,image text NOT NULL,UNIQUE KEY id (id));";
dbDelta($sql);
add_option("jal_db_version", $jal_db_version);
}
}
function delete_banner_table() //Drop Table banner_upload
{
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
global $wpdb;	
$rs=$wpdb->query( "drop table wp_banner_upload" );
}
function add_banner_menu() //Adding submenu under setting menu of plugin Banner Upload.
{
add_menu_page( 'options-general.php', 'Banner Upload', 'manage_options', 'banner_listing', 'banner_listing_function',plugins_url('/BannerUpload/banner.png'));
add_submenu_page( 'Banner Upload', 'Banner Upload', 'Uploading Banner Upload', 'manage_options', 'banner_upload', 'banner_add_function');
add_submenu_page( 'Banner Upload', 'Banner Upload', 'Uploading Banner Upload', 'manage_options', 'banner_edit', 'banner_edit_function');
add_submenu_page( 'Banner Upload', 'Banner Upload', 'Uploading Banner Upload', 'manage_options', 'banner_insert', 'banner_insert_function');
add_submenu_page( 'Banner Upload', 'Banner Upload', 'Uploading Banner Upload', 'manage_options', 'banner_update', 'banner_update_function');
add_submenu_page( 'Banner Upload', 'Banner Upload', 'Uploading Banner Upload', 'manage_options', 'banner_delete', 'banner_delete_function');
}
function banner_listing_function() //Calling function for Showing banner deatils in a list.
{
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
global $wpdb;
$res=$wpdb->get_var("select count(*) from wp_banner_upload");
$no_of_records = 8;
$result1=(int)$res;
$total_pages=ceil($result1 /  $no_of_records);
$pageno = $_REQUEST['page_no'];
if(empty($pageno))
{
$pageno=1;
}
$rs=$wpdb->get_results( "SELECT  * FROM  `wp_banner_upload` ORDER BY `orderno` ASC  limit " . ($pageno-1) * $no_of_records. "," . $no_of_records );
?>
<br/><br/>
<p style="float:right;">
<a href="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=banner_upload"><input name="Add banner" id="submit" class="button-primary"  value="Banner Upolad" type="submit"></a>
</p>
<br/><br/>
<p>
<h2>Listing Banner Details</h2>
</p>
<table class="wp-list-table widefat fixed pages" cellspacing="0" width="95%">
<tr><td bgcolor="#F3FAFE" width="5%"><strong>Order No</strong></td><td bgcolor="#F3FAFE" width="10%"><strong>Banner</strong></td><td bgcolor="#F3FAFE" width="5%"><strong>Edit</strong></td><td bgcolor="#F3FAFE" width="5%"><strong>Delete</strong></td></tr>
<?php
foreach($rs as $row)
{
?>
<tr>
<td bgcolor="#F2F9FF"><?php echo $row->orderno; ?></td>
<td bgcolor="#F2F9FF"><img src="<?php echo $row->image; ?>" width="278" height="150"/></td>
<td bgcolor="#F2F9FF"><a href="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=banner_edit&id=<?php echo $row->id; ?>">edit</a></td>
<td bgcolor="#F2F9FF"><a href="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=banner_delete&id2=<?php echo $row->id; ?>" >delete</a></td>
</tr>
<?php
   }
?>
</table>
<a class="PagingText">Page <?php echo $pageno ; ?> of <?php echo $total_pages; ?>.</a>
<?php
for($i=1;$i<=$total_pages;$i++)
{
?>
<a  href="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=banner_listing&page_no=<?php echo $i; ?>">
<?php echo $i; ?></a>
<?php
}
?>
<?php
}
/////////////////Delete ////////////////////////////////////
function banner_delete_function() // Calling function for delete gallery details.
{
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
global $wpdb;
$id=$_REQUEST['id'];
$delete="delete from wp_banner_upload where id='"  .$_REQUEST['id2']. "' ";
//unlink('../wp-content/plugins/BannerUpload/upload/'.$_REQUEST['id2']);	
$wpdb->query($delete);
$path=get_option('siteurl');
?>
<script>
document.location.href ="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=banner_listing";
</script>
<?php		  
}
function banner_add_function() //Calling function for Adding a new banner.
{
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
global $wpdb;
?>
<html>
<head>
<script type="text/javascript">
var maxWidth=100;
var maxHeight=100;
var fileTypes=["bmp","gif","png","jpg","jpeg"];
var outImage="previewField";
var defaultPic="spacer.gif";
function preview(what)
{
var source=what.value;
var ext=source.substring(source.lastIndexOf(".")+1,source.length).toLowerCase();
for (var i=0; i<fileTypes.length; i++) if (fileTypes[i]==ext) break;
globalPic=new Image();
if (i<fileTypes.length)
{ 
globalPic.src=source;
return true;
}
else if(source == "")
return true;
else 
{
globalPic.src=defaultPic;
alert("THAT IS NOT A VALID IMAGE\nPlease load an image with an extention of one of the following:\n\n"+fileTypes.join(", "));
return false;
  }
setTimeout("applyChanges()",200);
}
var globalPic;
function applyChanges(){
var field=document.getElementById(outImage);
var x=parseInt(globalPic.width);
var y=parseInt(globalPic.height);
if (x>maxWidth) {
  y*=maxWidth/x;
  x=maxWidth;
}
if (y>maxHeight) {
  x*=maxHeight/y;
  y=maxHeight;
}
field.style.display=(x<1 || y<1)?"none":"";
field.src=globalPic.src;
field.width=x;
field.height=y;
}
function validate(what)
{
var source=what.value;
if(source == "")
{
alert("please upload image");
return false;
}
else
return true;
}
</script>
</head>
<body>
<form name="form" action="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=banner_insert" method="post" onSubmit="return preview(document.form.picture);" enctype="multipart/form-data">
<table>
<tr><th><h4>Banner Upload</h4></th></tr>
<tr><td>OrderNo:</td><td><input type="text" name="oredrno" value=""  size="30"></td></tr>
<tr><td>Caption:</td><td><textarea name="caption" rows="5" cols="30"></textarea></td></tr>
<tr><td>Banner Upload:</td><td><input type="file" name="picture" value=""  size="25"><span style="color:#F00; font-size:13px; font-weight:bold;"> ( For banner size: 1600 X 613 )</span></td></tr>
<tr><td></td><td><input type="submit" value="Add banner" name="Add" id="post-query-submit" class="button-secondary"/></td></tr>
</table>
</form>
</body>  
</html>
<?php
}
function banner_insert_function() // Insert banner Image.
{
if (isset($_POST['Add']))
{
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
global $wpdb;
$target="../wp-content/plugins/BannerUpload/upload/".$_FILES["picture"]["name"];
$img=time().$_FILES["picture"]["name"];
$target_path = "../wp-content/plugins/BannerUpload/upload/".$img;
move_uploaded_file($_FILES['picture']['tmp_name'],$target_path);
$path=get_option('siteurl')."/wp-content/plugins/BannerUpload/upload/".$img;
$insert = "INSERT INTO " . wp_banner_upload . " (orderno,caption,image) " . "VALUES ('" . $_POST['oredrno'] . "','" . $_POST['caption'] . "','" . $path . "')";
$wpdb->query( $insert );
$path=get_option('siteurl');
?>
<script>
document.location.href ="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=banner_listing";
</script>
<?php		    
}	
}
function banner_edit_function() // Calling function for editing banner details.
{
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
global $wpdb;
$id=$_REQUEST['id'];
$rs=$wpdb->get_row("SELECT  * FROM  `wp_banner_upload` where `id`='".$id."'");
?>
<form name="form" action="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=banner_update&id1=<?php echo $id; ?>" method="post" enctype="multipart/form-data">
<table>
<tr><th><h4>Edit Banner Upload</h4></th></tr>
<tr><td>Order No:</td><td><input type="text" name="orderno" size="30" value="<?php echo $rs->orderno; ?>" /></td></tr>
<tr><td>Caption:</td><td><textarea name="caption" rows="5" cols="30"><?php echo $rs->caption; ?></textarea></td></tr>
<tr><td>Banner Upload :</td><td><input type="file" name="picture" value=""  size="22"><span style="color:#F00; font-size:13px; font-weight:bold;"> ( For banner size: 1600 X 613 )</span></td></tr>
<tr><td></td><td><input type="submit" value="Update banner" name="Add" id="post-query-submit" class="button-secondary"/></td></tr>
</table>
</form>    
<?php
}
function banner_update_function()
{
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
global $wpdb;
if(is_uploaded_file($_FILES["picture"]["tmp_name"])!="")
{ 
$target="../wp-content/plugins/BannerUpload/upload/".$_FILES["picture"]["name"];
$img=time().$_FILES["picture"]["name"];
$target_path = "../wp-content/plugins/BannerUpload/upload/".$img;
move_uploaded_file($_FILES["picture"]["tmp_name"],$target_path);
$path=get_option('siteurl')."/wp-content/plugins/BannerUpload/upload/".$img;
$id1=$_REQUEST['id1'];
$update="UPDATE `wp_banner_upload` SET image='"  . $path . "' WHERE id='"  . $id1 . "' ";
$wpdb->query($update);
}
if(is_uploaded_file($_FILES["picture"]["tmp_name"])=="")
{ 
$target="../wp-content/plugins/BannerUpload/upload/".$_FILES["picture"]["name"];
$img=time().$_FILES["picture"]["name"];
$target_path = "../wp-content/plugins/BannerUpload/upload/".$img;
move_uploaded_file($_FILES["picture"]["tmp_name"],$target_path);
$path=get_option('siteurl')."/wp-content/plugins/BannerUpload/upload/".$img;
$id1=$_REQUEST['id1'];
$update="UPDATE `wp_banner_upload` SET orderno='".$_POST['orderno']."',caption='".$_POST['caption']."' WHERE id='"  . $id1 . "' ";
$wpdb->query($update);
}
?>
<script>
document.location.href ="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=banner_listing";
</script>
<?php	
}
?>
